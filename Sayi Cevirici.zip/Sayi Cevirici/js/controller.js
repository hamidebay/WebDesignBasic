/**
 * UI Logic (Controller)
 */
$(document).ready(function () {
    $("#calculate_btn").click(function () {
        let input_value = $("#input").val();
        let selectedLanguage = $("#languages").find("option:selected").val();
             if (selectedLanguage === "türkce") {
                console.log(selectedLanguage);
            let converted = convert(input_value);
            $("#output").html(converted);
        }
        if (selectedLanguage === "english") {
            console.log(selectedLanguage);
            let convertedEnglish = convertEN(input_value);
            $("#output").html(convertedEnglish);
        };
    });


});


/* bir digital saat olusturulacak
1. Saat, dakika, saniye ve milisaniyeyi gösterecek.
2. Saat alanina tiklayinca 12 lik ya da 24 lük gösterim birimleri arasinda degisecek.
3. aktüel epoch degeri gösterilecek.
4. Log butonuna basilinca, butona basilma zamani, butonun altinda olan bir listeye eklenecek.
*/
let date = new Date();
let hours = date.getHours();
let minutes = date.getMinutes();
let seconds = date.getSeconds();
let miliSeconds = date.getMilliseconds();

function showTime() {

    minutes = checkTime(minutes);
    seconds = checkTime(seconds);
    //miliSeconds = checkTime(miliSeconds);
    let time = hours + ":" + minutes + ":" + seconds + ":" + miliSeconds;

    return time;
}

function interval() {
    let t = setInterval(showTime, 1000);
    return t;
}


function checkTime(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}

function changeTimeUnit(hours, minutes, seconds, miliSeconds) {
    this.hours = hours;
    this.minutes = minutes;
    this.seconds = seconds;
    this.miliSeconds = miliSeconds;

    if (hours <= 12) {
        hours += 12;
    } else {
        hours = hours - 12;
    }

    minutes = checkTime(minutes);
    seconds = checkTime(seconds);
    //miliSeconds = checkTime(miliSeconds);
    let t = setInterval(function () {
        changeTimeUnit()
    }, 500);

    let newTime = hours + ":" + minutes + ":" + seconds + ":" + miliSeconds;
    //console.log(hours);
    return newTime;

}

function showEpochValue(time) {

}

function listOfClickTimes(clicktime) {

}
showTime();

function main() {
    showTime();
    changeTimeUnit();
    showEpochValue();
    listOfClickTimes();
}
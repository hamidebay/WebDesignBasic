class Racer {

    constructor(pName) {
        this.name = pName;
    }

    getName(){
        return this.name;
    }
}




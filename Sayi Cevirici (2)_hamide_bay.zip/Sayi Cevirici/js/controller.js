/**
 * UI Logic (Controller)
 */
$(document).ready(function () {
    $("#calculate_btn").click(function () {
        
        let selectedLanguage = $("#languages").find("option:selected").val();
        if (selectedLanguage === "türkce") {
            console.log(selectedLanguage);
            let input_value = $("#input").val();
            let converted = convert(input_value);
            $("#output").html(converted);
        }
        if (selectedLanguage === "english") {
            console.log(selectedLanguage);
            let input_valueEN = $("#input").val();
            let convertedEnglish = convertEN(input_valueEN);
            console.log(convertedEnglish);
            $("#output").html(convertedEnglish);
        };
     
    });


});
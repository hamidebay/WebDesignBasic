$(document).ready(function(){

$("#time-display").html(interval());
//$("#time-display").click(function(){$("#time-display").html(changeTimeUnit());
//});

});

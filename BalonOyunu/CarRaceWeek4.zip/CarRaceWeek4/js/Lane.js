class Lane {

    constructor(pCar) {
        this.car = pCar;
        this.size = 100;
    }


    getSize(){
        return this.size;
    }

    getCar(){
        return this.car;
    }
}
/*
1. Sayiyi yazma yerine yaz 
2. Buttona bas
3. Sayiyi texte cevir (ingilizce)
3.1 tek haneli sayilari cevir
3.2 cift haneli sayilari (onar) cevir
3.3 üc haneli sayilari(yüzer) cevir
3.4 dört-alti haneli sayilari(biner) cevir
3.5 7-9 haneli sayilari(milyon) cevir
3.6 10-12 haneli sayilari(milyar) cevir
4. Cevrilmis texti ekranda göster.
*/

let single_digits = new Map();
single_digits.set("0", "null");
single_digits.set("1", "one");
single_digits.set("2", "two");
single_digits.set("3", "three");
single_digits.set("4", "four");
single_digits.set("5", "five");
single_digits.set("6", "six");
single_digits.set("7", "seven");
single_digits.set("8", "eight");
single_digits.set("9", "nine");

let double_digits = new Map();
double_digits.set("1", "ten");
double_digits.set("2", "twenty");
double_digits.set("3", "thirty");
double_digits.set("4", "fourty");
double_digits.set("5", "fifty");
double_digits.set("6", "sixty");
double_digits.set("7", "seventy");
double_digits.set("8", "eightty");
double_digits.set("9", "ninety");

let hundred_identifier = "one hundred";
let tousend_identifier = "tousend";
let million_identifier = "million";
let billion_identifier = "billion";


function calculateSingleDigit(input) {
    return single_digits.get(input);
}

function calculateDoubleDigit(input) {
    if (input[0] === "0") {
        return input[1] !== "0" ? calculateSingleDigit(input[1]) : "";
    }
    return double_digits.get(input[0]) + " " +
        (input[1] !== "0" ?
            calculateSingleDigit(input[1]) :
            "");
}

function calculateTrippleDigit(input) {
    let chars = input.split("");
    if (input[0] === "0") {
        return calculateDoubleDigit(input.substr(1));
    }
    return (chars[0] === "1" ? hundred_identifier :
            calculateSingleDigit(input[0]) + " " + hundred_identifier) +
        " " + calculateDoubleDigit(input.substr(1).split(""));
}

function calculateThousandStepsDigits(input) {
    if (input.length === 4) {
        return input[0] === "1" ?
            tousend_identifier + " " + calculateTrippleDigit(input.substr(1)) :
            calculateSingleDigit(input[0]) + " " + tousend_identifier + " " + calculateTrippleDigit(input.substr(1));
    }
    if (input.length === 5) {
        return calculateDoubleDigit(input.substr(0, 2)) + " " + tousend_identifier + " " + calculateTrippleDigit(input.substr(2));
    }
    if (input.length === 6) {
        return calculateTrippleDigit(input.substr(0, 3)) + " " + tousend_identifier + " " + calculateTrippleDigit(input.substr(3));
    }
}

function calculateMillionDigits(input) {
    if (input.length === 7) {
        return calculateSingleDigit(input[0]) + " " + million_identifier + " " + calculateThousandStepsDigits(input.substr(1));
    }

    if (input.length === 8) {
        return calculateDoubleDigit(input.substr(0, 2)) + " " + million_identifier + " " + calculateThousandStepsDigits(input.substr(2));
    }

    if (input.length === 9) {
        return calculateTrippleDigit(input.substr(0, 3)) + " " + million_identifier + " " + calculateThousandStepsDigits(input.substr(3));
    }

}

function calculateMiliardenDigits(input) {
    if (input.length === 10) {
        return calculateSingleDigit(input[0]) + " " + billion_identifier + " " + calculateMillionDigits(input.substr(1));
    }

    if (input.length === 11) {
        return calculateDoubleDigit(input.substr(0, 2)) + " " + billion_identifier + " " + calculateMillionDigits(input.substr(2));
    }

    if (input.length === 12) {
        return calculateTrippleDigit(input.substr(0, 3)) + " " + billion_identifier + " " + calculateMillionDigits(input.substr(3));
    }
}

function convertEN(input) {
    if (input.length === 1) {
        return calculateSingleDigit(input);
    }
    if (input.length === 2) {
        return calculateDoubleDigit(input.split(""));
    }
    if (input.length === 3) {
        return calculateTrippleDigit(input);
    }
    if (input.length > 3 && input.length < 7) {
        return calculateThousandStepsDigits(input);
    }

    if (input.length > 6 && input.length < 10) {
        // TODO: Students from here...
        return calculateMillionDigits(input);
    }
    if (input.length > 9 && input.length < 13) {
        return calculateMiliardenDigits(input);
    }
    if (input.length > 12) {
        alert("Out of Range!");
    }
}
class Location{

    constructor(pX, pY){
        this.left = pX;
        this.top  = pY;
    }

}
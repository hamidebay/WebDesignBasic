/*
1. Sayiyi yazma yerine yaz 
2. Buttona bas
3. Sayiyi texte cevir (ingilizce)
3.1 tek haneli sayilari cevir
3.2 cift haneli sayilari (onar) cevir
3.3 üc haneli sayilari(yüzer) cevir
3.4 dört-alti haneli sayilari(biner) cevir
3.5 7-9 haneli sayilari(milyon) cevir
3.6 10-12 haneli sayilari(milyar) cevir
4. Cevrilmis texti ekranda göster.
*/

let single_digits = new Map();
single_digits.set("0", "null");
single_digits.set("1", "one");
single_digits.set("2", "two");
single_digits.set("3", "three");
single_digits.set("4", "four");
single_digits.set("5", "five");
single_digits.set("6", "six");
single_digits.set("7", "seven");
single_digits.set("8", "eight");
single_digits.set("9", "nine");

let double_digits = new Map();
double_digits.set("1", "ten");
double_digits.set("2", "twenty");
double_digits.set("3", "thirty");
double_digits.set("4", "fourty");
double_digits.set("5", "fifty");
double_digits.set("6", "sixty");
double_digits.set("7", "seventy");
double_digits.set("8", "eightty");
double_digits.set("9", "ninety");
double_digits.set("11", "eleven");
double_digits.set("12", "twelfe");
double_digits.set("13", "thirteen");
double_digits.set("15", "fifteen");

let hundred_identifier = "hundred";
let tousend_identifier = "tousend";
let million_identifier = "million";
let billion_identifier = "billion";
let ten_identifier = "ten";
let eleven_identifier = "eleven";
let twelfe_identifier = "twelfe";
let thirteen_identifier = "thirteen";
let fifteen_identifier = "fifteen";
let teen_identifier = "teen";

function calculateSingleDigitEN(input) {
    return single_digits.get(input);
}

function calculateDoubleDigitEN(input) {
    if (input[0] === "0") {
        return input[1] !== "0" ? calculateSingleDigitEN(input[1]) : "";
    }
  
    if (input[0] === "1" && input[1] === "0") {
        return ten_identifier;
    }
    if (input[0] === "1" && input[1] === "1") {
        return eleven_identifier;
    }
    if (input[0] === "1" && input[1] === "2") {
        return twelfe_identifier;
    }
    if (input[0] === "1" && input[1] === "3") {
        return thirteen_identifier;
    }
    if (input[0] === "1" && input[1] === "5") {
        return fifteen_identifier;
    }
    if(input[0] > "1"){
        return double_digits.get(input[0])+
    (input[1] !== "0" ?
        calculateSingleDigitEN(input[1]) :
        "");
    }
   
    else {
        return calculateSingleDigitEN(input[1]) + teen_identifier;
    }
    /*
         if (input[0] === "0") {
          return input[1] !== "0" ? calculateSingleDigitEN(input[1]) : "";
      }
      return double_digits.get(input[0]) + " " +
          (input[1] !== "0" ?
              calculateSingleDigitEN(input[1]) :
              "");
              */
}

function calculateTrippleDigitEN(input) {
    let chars = input.split("");
    if (input[0] === "0") {
        return calculateDoubleDigitEN(input.substr(1));
    }
    /*if(input[0] === "1"){
        return calculateSingleDigitEN(input[0]) +" " + hundred_identifier + " " + calculateDoubleDigitEN(input) + " " + calculateSingleDigitEN(input[2]);
    }
    */
    return  calculateSingleDigitEN(input[0]) + " " + hundred_identifier +
        " " + calculateDoubleDigitEN(input.substr(1).split(""));
}

function calculateThousandStepsDigitsEN(input) {
    if (input.length === 4) {
        return input[0] === "1" ?
            tousend_identifier + " " + calculateTrippleDigitEN(input.substr(1)) :
            calculateSingleDigitEN(input[0]) + " " + tousend_identifier + " " + calculateTrippleDigitEN(input.substr(1));
    }
    if (input.length === 5) {
        return calculateDoubleDigitEN(input.substr(0, 2)) + " " + tousend_identifier + " " + calculateTrippleDigitEN(input.substr(2));
    }
    if (input.length === 6) {
        return calculateTrippleDigitEN(input.substr(0, 3)) + " " + tousend_identifier + " " + calculateTrippleDigitEN(input.substr(3));
    }
}

function calculateMillionDigitsEN(input) {
    if (input.length === 7 ) {
        if(input[1] && input[2] && input[3]  === "0"){
            return calculateSingleDigitEN(input[0]) + " " + million_identifier + " " + calculateTrippleDigitEN(input.substr(4, 6));
        }
        return calculateSingleDigit(input[0]) + " " + milyon_identifier + " " + calculateTrippleDigit(input.substr(1, 3)) + " " + bin_identifier + " " + calculateTrippleDigit(input.substr(4));
    }

    if (input.length === 8) {
        return calculateDoubleDigitEN(input.substr(0, 2)) + " " + million_identifier + " " + calculateThousandStepsDigitsEN(input.substr(2));
    }

    if (input.length === 9) {
        return calculateTrippleDigitEN(input.substr(0, 3)) + " " + million_identifier + " " + calculateThousandStepsDigitsEN(input.substr(3));
    }

}

function calculateMiliardenDigitsEN(input) {
    if (input.length === 10) {
        if(input[1] && input[2] && input[3]  === "0"){
            return calculateSingleDigitEN(input[0]) + " " + billion_identifier + " " + calculateThousandStepsDigitsEN(input.substr(4, 6));
        }
        if(input[4] && input[5] && input[6] === "0" ){
            return calculateSingleDigitEN(input[0]) + " " + billion_identifier + " " + calculateTrippleDigitEN(input.substr(1, 3)) + " " + million_identifier + " " + calculateTrippleDigitEN(input.substr(7, 9));
        }
        if(input[1] && input[2] && input[3] && input[4] && input[5] && input[6] === "0" ){
            return calculateSingleDigitEN(input[0]) + " " + billion_identifier + " " +  calculateTrippleDigitEN(input.substr(7, 9));
        }
        return calculateSingleDigitEN(input[0]) + " " + billion_identifier + " " + calculateMillionDigitsEN(input.substr(1));
    }

    if (input.length === 11) {
        return calculateDoubleDigitEN(input.substr(0, 2)) + " " + billion_identifier + " " + calculateMillionDigitsEN(input.substr(2));
    }

    if (input.length === 12) {
        return calculateTrippleDigitEN(input.substr(0, 3)) + " " + billion_identifier + " " + calculateMillionDigitsEN(input.substr(3));
    }
}

function convertEN(input) {
    if (input.length === 1) {
        return calculateSingleDigitEN(input);
    }
    if (input.length === 2) {
        return calculateDoubleDigitEN(input.split(""));
    }
    if (input.length === 3) {
        return calculateTrippleDigitEN(input);
    }
    if (input.length > 3 && input.length < 7) {
        return calculateThousandStepsDigitsEN(input);
    }

    if (input.length > 6 && input.length < 10) {
        // TODO: Students from here...
        return calculateMillionDigitsEN(input);
    }
    if (input.length > 9 && input.length < 13) {
        return calculateMiliardenDigitsEN(input);
    }
    if (input.length > 12) {
        alert("Out of Range!");
    }
}
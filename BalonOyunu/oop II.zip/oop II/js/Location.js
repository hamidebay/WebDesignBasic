


// tarif
class Location {

    constructor(pLeft, pTop) {
        this.left = pLeft;
        this.top = pTop;
    }
}


// örnek

const lo1 = new Location(300, 450);
const lo2 = new Location(100, -400);
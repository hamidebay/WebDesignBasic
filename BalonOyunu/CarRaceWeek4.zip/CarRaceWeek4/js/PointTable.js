class PointTable {

    constructor(pRacersName,  pPoints) {
        this.racersName = pRacersName;
        this.points = pPoints;
    }

}